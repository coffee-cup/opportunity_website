Opportunity IOS App
===================

This is the repository that is the IOS app for 2016 SENG 321 class project. Open the workspace in XCode to run the app. Dependencies are installed with [CocoaPods](https://cocoapods.org/) using the command `pod install`.
