//
//  Opp.swift
//  Opportunity
//
//  Created by Jake Runzer on 2016-02-29.
//  Copyright © 2016 FixCode. All rights reserved.
//

import Foundation
import CoreData


class Opp: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}

extension Opp {
    func addConditionObject(value: Condition) {
//        let items = self.mutableArrayValueForKey("conditions")
//        items.addObject(value)
    }
    
    func removeConditionObject(value:Condition) {
//        let items = self.mutableSetValueForKey("conditions");
//        items.removeObject(value)
    }
}