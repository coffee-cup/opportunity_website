//
//  Hist.swift
//  Opportunity
//
//  Created by Jake Runzer on 2016-03-09.
//  Copyright © 2016 FixCode. All rights reserved.
//

import Foundation
import CoreData


class Hist: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
