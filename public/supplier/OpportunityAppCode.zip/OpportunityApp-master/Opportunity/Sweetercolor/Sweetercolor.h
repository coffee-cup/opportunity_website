//
//  Sweetercolor.h
//  Sweetercolor
//
//  Created by Jathu Satkunarajah - August 2015 - Toronto
//  Copyright (c) 2015 Jathu Satkunarajah. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Sweetercolor.
FOUNDATION_EXPORT double SweetercolorVersionNumber;

//! Project version string for Sweetercolor.
FOUNDATION_EXPORT const unsigned char SweetercolorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Sweetercolor/PublicHeader.h>


