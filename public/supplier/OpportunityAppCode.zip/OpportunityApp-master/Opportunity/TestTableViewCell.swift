//
//  TestTableViewCell.swift
//  Opportunity
//
//  Created by Jake Runzer on 2016-02-23.
//  Copyright © 2016 FixCode. All rights reserved.
//

import UIKit

class TestTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
