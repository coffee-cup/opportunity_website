//
//  craft.h
//  craft
//
//  Created by Tommy Leung on 6/28/14.
//  Copyright (c) 2014 Tommy Leung. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for craft.
FOUNDATION_EXPORT double craftVersionNumber;

//! Project version string for craft.
FOUNDATION_EXPORT const unsigned char craftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <craft/PublicHeader.h>