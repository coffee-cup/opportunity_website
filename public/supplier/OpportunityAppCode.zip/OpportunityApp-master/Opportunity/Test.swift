//
//  Test.swift
//  Opportunity
//
//  Created by Jake Runzer on 2016-02-27.
//  Copyright © 2016 FixCode. All rights reserved.
//

import UIKit

class Test: NSObject {
    let s = "asdf"
}
